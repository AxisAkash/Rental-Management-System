﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;


namespace RMS
{
    public partial class SignUp : Form
    {
        // ================== State ==================
        string cs = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";

        private bool _showPwd = false;                                   // (your flag)
        private System.Windows.Forms.Button _btnTogglePwd;               // ★ CHANGED: explicitly qualified to avoid ambiguity
        public bool IsTenantSignup { get; set; } = false;                // same as before

        // ================== Ctor ==================
        public SignUp()
        {
            InitializeComponent();

            // ★ ADDED: make sure all event handlers are wired
            this.Load += SignUp_Load;
            button1.Click += button1_Click;                              // “Payment” button
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            textBox4.TextChanged += textBox4_TextChanged;

            // Eye toggle button (kept your logic)
            _btnTogglePwd = new System.Windows.Forms.Button              // ★ CHANGED: explicitly qualified
            {
                Width = 28,
                Height = textBox3.Height,
                FlatStyle = FlatStyle.Flat,
                TabStop = false,
                Text = "👁",
                Font = new Font(Font.FontFamily, 9f),
                BackColor = SystemColors.Control
            };
            _btnTogglePwd.FlatAppearance.BorderSize = 1;
            _btnTogglePwd.Click += BtnTogglePwd_Click;                   // ★ ADDED

            this.Controls.Add(_btnTogglePwd);
            PositionEyeButton();                                         // ★ ADDED

            // keep button positioned next to password box
            textBox3.LocationChanged += (s, e) => PositionEyeButton();   // ★ ADDED
            textBox3.SizeChanged += (s, e) => {                          // ★ ADDED
                _btnTogglePwd.Height = textBox3.Height;
                PositionEyeButton();
            };
        }

        // ================== Background (unchanged) ==================
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                this.ClientRectangle,
                Color.White,
                Color.FromArgb(220, 235, 255),
                System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        // ================== Helpers ==================
        private void PositionEyeButton()                                  // ★ ADDED
        {
            if (_btnTogglePwd == null) return;
            _btnTogglePwd.Left = textBox3.Right + 4;
            _btnTogglePwd.Top = textBox3.Top;
        }

        private void BtnTogglePwd_Click(object sender, EventArgs e)       // ★ ADDED
        {
            _showPwd = !_showPwd;

            // if placeholder (gray) is showing, keep it visible; otherwise toggle masking
            textBox3.UseSystemPasswordChar = (textBox3.ForeColor == Color.Gray) ? false : !_showPwd;
            textBox2.UseSystemPasswordChar = (textBox2.ForeColor == Color.Gray) ? false : !_showPwd;

            _btnTogglePwd.Text = _showPwd ? "🙈" : "👁";
        }

        private void SetPlaceholder(System.Windows.Forms.TextBox txt, string placeholder, bool isPassword = false) // ★ CHANGED: fully qualified TextBox
        {
            if (!(txt.Tag is string) || (string)txt.Tag != "ph_attached")
            {
                txt.Enter += (s, e) =>
                {
                    if (txt.ForeColor == Color.Gray)
                    {
                        txt.Text = "";
                        txt.ForeColor = Color.Black;
                        if (isPassword) txt.UseSystemPasswordChar = !_showPwd;
                    }
                };

                txt.Leave += (s, e) =>
                {
                    if (string.IsNullOrWhiteSpace(txt.Text))
                    {
                        txt.Text = placeholder;
                        txt.ForeColor = Color.Gray;
                        if (isPassword) txt.UseSystemPasswordChar = false;
                    }
                };

                txt.Tag = "ph_attached";
            }

            txt.Text = placeholder;
            txt.ForeColor = Color.Gray;
            if (isPassword) txt.UseSystemPasswordChar = false;
        }

        private bool IsValidPassword(string pwd)
        {
            return pwd.Length >= 6 && pwd.Any(char.IsUpper) && pwd.Any(char.IsLower) && pwd.Any(char.IsDigit);
        }

        private void ResetForm()                                          // ★ ADDED
        {
            textBox1.Text = "";
            comboBox1.SelectedIndex = -1;
            dateTimePicker1.Value = DateTime.Today;

            _showPwd = false;
            _btnTogglePwd.Text = "👁";

            SetPlaceholder(textBox3, "Enter your password", true);
            SetPlaceholder(textBox2, "Confirm Password", true);

            checkBox1.Checked = false;
            checkBox2.Checked = false;

            button1.Visible = false;
            comboBox2.Visible = false;
            comboBox2.SelectedIndex = -1;

            textBox4.Visible = false;
            textBox5.Visible = false;
            SetPlaceholder(textBox4, "Enter the amount 5000");
            SetPlaceholder(textBox5, "Enter your premium password");

            PositionEyeButton();
        }

        // ================== Form Load ==================
        private void SignUp_Load(object sender, EventArgs e)              // ★ ADDED
        {
            // hide premium UI initially
            button1.Visible = false;     // Payment
            comboBox2.Visible = false;   // payment method
            textBox4.Visible = false;    // amount
            textBox5.Visible = false;    // premium password

            // placeholders
            SetPlaceholder(textBox4, "Enter the amount 5000");
            SetPlaceholder(textBox5, "Enter your premium password");
            SetPlaceholder(textBox3, "Enter your password", true);
            SetPlaceholder(textBox2, "Confirm Password", true);

            PositionEyeButton();

            if (IsTenantSignup)
            {
                // Tenant: hide Normal/Premium choice; default to Normal
                checkBox1.Visible = false;       // Premium
                checkBox2.Visible = false;       // Normal
                checkBox1.Checked = false;
                checkBox2.Checked = true;

                button1.Visible = false;
                comboBox2.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = false;
            }
        }

        // ================== UI events wired in Designer or ctor ==================
        private void checkBox2_CheckedChanged(object sender, EventArgs e) // Normal
        {
            if (checkBox2.Checked)
            {
                checkBox1.Checked = false;
                button1.Visible = false;
                comboBox2.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e) // Premium
        {
            if (checkBox1.Checked)
            {
                checkBox2.Checked = false;
                button1.Visible = true;     // show “Payment” button
                comboBox2.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = false;
            }
            else
            {
                button1.Visible = false;
                comboBox2.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)            // Payment button
        {
            comboBox2.Visible = true;
            textBox4.Visible = false;
            textBox5.Visible = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox4.Visible = true;
            SetPlaceholder(textBox4, "Enter the amount 5000");
            textBox5.Visible = false;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            bool userTyped = textBox4.ForeColor != Color.Gray;
            bool amountIs5000 = userTyped && textBox4.Text.Trim() == "5000";
            textBox5.Visible = amountIs5000;
        }

        // ================== Buttons ==================
        private void button2_Click(object sender, EventArgs e)            // Back
        {
            var home = new Form1();
            home.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)            // SignUp submit
        {
            // ---- gather values ----
            string Id= textBox6.Text.Trim();                         // ★ your new ID field
            if (!int.TryParse(Id, out int idValue))
            {
                MessageBox.Show("Please enter a valid numeric ID.");
                return;
            }

            string name = textBox1.Text.Trim();
            DateTime dob = dateTimePicker1.Value;
            string gender = comboBox1.SelectedItem?.ToString() ?? "";
            string password = (textBox3.ForeColor == Color.Gray) ? "" : textBox3.Text.Trim();
            string confirmPassword = (textBox2.ForeColor == Color.Gray) ? "" : textBox2.Text.Trim();
            string premium = checkBox1.Checked ? "Yes" : "No";
            string normal = checkBox2.Checked ? "Yes" : "No";
            string amount = (textBox4.ForeColor == Color.Gray) ? "" : textBox4.Text.Trim();
            string premiumPass = (textBox5.ForeColor == Color.Gray) ? "" : textBox5.Text.Trim();

            // ---- validation (kept your logic) ----
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter your name.");
                return;
            }
            if (string.IsNullOrWhiteSpace(gender))
            {
                MessageBox.Show("Please select your Gender.");
                return;
            }
            if (string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter your password.");
                return;
            }
            if (!IsValidPassword(password))
            {
                MessageBox.Show("Password must be at least 6 characters, include uppercase, lowercase, and a number.");
                return;
            }
            if (string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("Please confirm your password.");
                return;
            }
            if (!string.Equals(password, confirmPassword))
            {
                MessageBox.Show("Passwords do not match!");
                return;
            }

            // ---- success feedback for UI-only branch ----
            if (checkBox2.Checked)
            {
                MessageBox.Show("Normal Signup Successful!");
                // continue into DB save below (tenant or owner)
            }
            else if (checkBox1.Checked)
            {
                bool premiumReady =
                    textBox4.Visible &&
                    textBox4.ForeColor != Color.Gray &&
                    amount == "5000" &&
                    textBox5.Visible &&
                    textBox5.ForeColor != Color.Gray &&
                    !string.IsNullOrWhiteSpace(premiumPass);

                if (!premiumReady)
                {
                    MessageBox.Show("Please complete all premium fields (amount must be 5000).");
                    return;
                }

                MessageBox.Show("Premium Signup Successful with Payment!");
            }

            if (IsTenantSignup)
            {
                const string sql = @"INSERT INTO [user] 
                                    (Id, name, dob, gender, password)
                                     VALUES (@Id, @name, @dob, @gender, @password)";
                using (var conn = new SqlConnection(cs))
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", idValue);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@dob", dob);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@password", password); 

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Profile created successfully!", "Success",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        USER_DASHBOARD dash = new USER_DASHBOARD();                   // uses your existing ctor
                        dash.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to create the profile. Please try again.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                const string sql = @"INSERT INTO [owner]
                                     (Id, name, dob, gender, password, premium, normal, premiumPass)
                                     VALUES (@Id, @name, @dob, @gender, @password, @premium, @normal, @premiumPass)";
                using (var conn = new SqlConnection(cs))
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", idValue);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@dob", dob);
                    cmd.Parameters.AddWithValue("@gender", gender);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@premium", premium);
                    cmd.Parameters.AddWithValue("@normal", normal);
                    if (premium == "Yes")
                    {
                        cmd.Parameters.AddWithValue("@amount", amount);
                        cmd.Parameters.AddWithValue("@premiumPass", premiumPass);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@amount", DBNull.Value);
                        cmd.Parameters.AddWithValue("@premiumPass", DBNull.Value);
                    }

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Profile created successfully!", "Success",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        var home = new Form1();
                        home.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to create the profile. Please try again.",
                                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}