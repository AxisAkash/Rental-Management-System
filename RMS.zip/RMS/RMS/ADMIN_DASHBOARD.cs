﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMS
{
    public partial class ADMIN_DASHBOARD : Form
    {

        string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(this.ClientRectangle,
                    Color.White, Color.FromArgb(220, 235, 255), // light blue
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        private DataGridView _activeGrid;
       
        public ADMIN_DASHBOARD()
        {
            InitializeComponent();

            // Top 4 buttons → show exactly one grid
            button1.Click += (s, e) => ShowGridAndEnableActions(dataGridView1, DataForFlats());
            button2.Click += (s, e) => ShowGridAndEnableActions(dataGridView2, DataForRooms());
            button3.Click += (s, e) => ShowGridAndEnableActions(dataGridView3, DataForOwners());
            button5.Click += (s, e) => ShowGridAndEnableActions(dataGridView4, DataForUsers());

            // Search (hidden until one of the top 4 is clicked)
            button8.Click += (s, e) => ShowSearchResults();

            // Select / Delete
            //button4.Click += (s, e) => HandleSelect();
            button6.Click += (s, e) => HandleDelete();

            this.Load += ADMIN_DASHBOARD_Load;
        }

        private void ADMIN_DASHBOARD_Load(object sender, EventArgs e)
        {
            PrepareGrid(dataGridView1);
            PrepareGrid(dataGridView2);
            PrepareGrid(dataGridView3);
            PrepareGrid(dataGridView4);

            SetAllGridsVisible(false);
            ShowSelectDelete(false);
            ShowSearchControls(false);
        }

        private void PrepareGrid(DataGridView dgv)
        {
            dgv.Visible = false;
            dgv.ReadOnly = true;
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.RowHeadersVisible = false;
        }

        private void SetAllGridsVisible(bool visible)
        {
            dataGridView1.Visible = visible;
            dataGridView2.Visible = visible;
            dataGridView3.Visible = visible;
            dataGridView4.Visible = visible;
        }

        private void ShowGridAndEnableActions(DataGridView target, object dataSource)
        {
            SetAllGridsVisible(false);

            // TODO [DB]: bind your real data (DataTable/BindingList/etc.)
            target.DataSource = dataSource;

            target.Visible = true;
            _activeGrid = target;

            ShowSelectDelete(true);
            ShowSearchControls(true);
        }

        private void ShowSearchControls(bool show)
        {
            button8.Visible = show;   // Search button
            textBox1.Visible = show;  // Search textbox (ensure this is your search box)
        }

        private void ShowSelectDelete(bool show)
        {
            //button4.Visible = show;   // Select
            button6.Visible = show;   // Delete
        }

        private void ShowSearchResults()
        {
            if (_activeGrid == null)
            {
                MessageBox.Show("Please select a table first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string searchValue = textBox1.Text.Trim();
            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a search value.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "";
            if (_activeGrid == dataGridView1) // Flats
            {
                query = @"SELECT FlatID, OwnerName, Rent, Available
              FROM Flat
              WHERE FlatID LIKE @term OR OwnerName LIKE @term OR CAST(Rent AS NVARCHAR) LIKE @term";
            }
            else if (_activeGrid == dataGridView2) // Rooms
            {
                query = @"SELECT OwnerName, FlatID, RoomNo, Rent, Available
              FROM Room
              WHERE FlatID LIKE @term OR OwnerName LIKE @term OR CAST(Rent AS NVARCHAR) LIKE @term";
            }
            else if (_activeGrid == dataGridView3) // Owners
            {
                query = @"SELECT Id, name, dob, gender, password, premium, normal, premiumPass
              FROM owner
              WHERE Id LIKE @term OR name LIKE @term";
            }
            else if (_activeGrid == dataGridView4) // Users
            {
                query = @"SELECT Id, name, dob, gender, password
              FROM [user]
              WHERE Id LIKE @term OR name LIKE @term";
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@term", "%" + searchValue + "%");
                DataTable dt = new DataTable();
                using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
                _activeGrid.DataSource = dt;

                if (dt.Rows.Count == 0)
                    MessageBox.Show("No matching rows found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void HandleSelect()
        {
            if (_activeGrid == null || _activeGrid.CurrentRow == null)
            {
                MessageBox.Show("Please select a row first.");
                return;
            }

            var id = _activeGrid.CurrentRow.Cells[0].Value; // assumes first column is key

            // TODO [DB]: fetch/open details by ID
            // e.g. var entity = repo.GetById(Convert.ToInt32(id));

            MessageBox.Show($"Selected ID: {id}");
        }

        private void HandleDelete()
        {
            if (_activeGrid == null || _activeGrid.CurrentRow == null)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            string table = "";
            string query = "";
            int rows = 0;

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.Connection = con;

                if (_activeGrid == dataGridView1) // Flat
                {
                    var flatId = _activeGrid.CurrentRow.Cells["FlatID"].Value;
                    table = "Flat";
                    query = $"DELETE FROM {table} WHERE FlatID=@id";
                    cmd.Parameters.AddWithValue("@id", flatId);
                }
                else if (_activeGrid == dataGridView2) // Room
                {
                    var flatId = _activeGrid.CurrentRow.Cells["FlatID"].Value;
                    var roomNo = _activeGrid.CurrentRow.Cells["RoomNo"].Value;
                    table = "Room";
                    query = $"DELETE FROM {table} WHERE FlatID=@flatId AND RoomNo=@roomNo";
                    cmd.Parameters.AddWithValue("@flatId", flatId);
                    cmd.Parameters.AddWithValue("@roomNo", roomNo);
                }
                else if (_activeGrid == dataGridView3) // Owner
                {
                    var id = _activeGrid.CurrentRow.Cells["Id"].Value;
                    table = "owner";
                    query = $"DELETE FROM {table} WHERE Id=@id";
                    cmd.Parameters.AddWithValue("@id", id);
                }
                else if (_activeGrid == dataGridView4) // User
                {
                    var id = _activeGrid.CurrentRow.Cells["Id"].Value;
                    table = "[user]";
                    query = $"DELETE FROM {table} WHERE Id=@id";
                    cmd.Parameters.AddWithValue("@id", id);
                }

                cmd.CommandText = query;
                con.Open();
                rows = cmd.ExecuteNonQuery();
            }

            if (rows > 0)
                MessageBox.Show("Deleted successfully!");
            else
                MessageBox.Show("Delete failed.");

            // Refresh grid
            if (_activeGrid == dataGridView1) _activeGrid.DataSource = DataForFlats();
            else if (_activeGrid == dataGridView2) _activeGrid.DataSource = DataForRooms();
            else if (_activeGrid == dataGridView3) _activeGrid.DataSource = DataForOwners();
            else if (_activeGrid == dataGridView4) _activeGrid.DataSource = DataForUsers();
        }



        // --- DB binding placeholders ---
        private DataTable DataForFlats()
        {
            string query = @"SELECT FlatID, OwnerName, Rent, Available FROM Flat";
            return GetDataTable(query);
        }

        private DataTable DataForRooms()
        {
            string query = @"SELECT OwnerName, FlatID, RoomNo, Rent, Available FROM Room";
            return GetDataTable(query);
        }

        private DataTable DataForOwners()
        {
            string query = @"SELECT Id, name, dob, gender, password, premium, normal, premiumPass FROM owner";
            return GetDataTable(query);
        }

        private DataTable DataForUsers()
        {
            string query = @"SELECT Id, name, dob, gender, password FROM [user]";
            return GetDataTable(query);
        }

        private DataTable GetDataTable(string query)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            {
                adapter.Fill(dt);
            }
            return dt;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var login = new Login();
            this.Hide();
            login.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

       


        private void button1_Click(object sender, EventArgs e)
        {




        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void Home_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
