﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace RMS
{
    public partial class UserProfile : Form
    {
        private readonly string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";
        private int _userId = 0;

        public UserProfile()
        {
            InitializeComponent();

            this.Load += UserProfile_Load;
            button1.Click += button1_Click; // Edit
            button2.Click += button2_Click; // Update
            button3.Click += button3_Click; // Back
        }

        private void UserProfile_Load(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
            SetEditMode(false);

            if (AppState.CurrentUserId <= 0)
            {
                MessageBox.Show("No logged-in user found.");
                Close();
                return;
            }
            _userId = AppState.CurrentUserId;

         
            textBox1.Text = "";
            textBox2.Text = "";

        }

    

        // ------- DB: read current profile by Id -------
        private void LoadUserProfile()
        {
            string query = "SELECT Id, name, password FROM [user] WHERE Id = @Id";
           
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", _userId);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            textBox1.Text = reader["name"].ToString();
                            textBox2.Text = reader["password"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("User not found.");
                        }
                    }
                }
            }


        // -------- Back --------
        private void button3_Click(object sender, EventArgs e)
        {
            USER_DASHBOARD d = new USER_DASHBOARD();
            Hide();
            d.Show();
        }

        // -------- Edit --------
        private void button1_Click(object sender, EventArgs e)
        {
            
            LoadUserProfile();
            SetEditMode(true);
            textBox2.UseSystemPasswordChar = false;
            textBox1.Focus();
            textBox1.SelectAll();
        }

        // -------- Update (Save) --------
        private void button2_Click(object sender, EventArgs e)
        {
       

            string newName = textBox1.Text.Trim();
            string newPassword = textBox2.Text.Trim();

            if (_userId <= 0)
            {
                MessageBox.Show("Cannot update: user id missing.");
                return;
            }

         
                string query = "UPDATE [user] SET name = @name, password=@password WHERE Id = @Id";
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@name", newName);
                    cmd.Parameters.AddWithValue("@password", newPassword);
                    cmd.Parameters.AddWithValue("@Id", _userId);

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Profile updated successfully.");
                          AppState.CurrentUserName = newName;
                          this.Hide();
                        USER_DASHBOARD uSER = new USER_DASHBOARD();
                        uSER.Show();
                        SetEditMode(false);
                        textBox2.UseSystemPasswordChar = true;
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please try again.");
                    }
                }
          
        }

        // -------- UI helpers --------
        private void SetEditMode(bool enabled)
        {
            textBox1.ReadOnly = !enabled;
            textBox2.ReadOnly = !enabled;

            textBox1.BackColor = enabled ? Color.White : SystemColors.ControlLightLight;
            textBox2.BackColor = enabled ? Color.White : SystemColors.ControlLightLight;

            button1.Enabled = !enabled; // Edit
            button2.Enabled = enabled;  // Update
        }

        // ★ CHANGED: Updated validation to account for placeholder text

        // background (unchanged)
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(this.ClientRectangle,
                    Color.White, Color.FromArgb(220, 235, 255),
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        // Other event handlers
        private void button2_Click_1(object sender, EventArgs e) => button2_Click(sender, e);
        private void button1_Click_1(object sender, EventArgs e) => button1_Click(sender, e);
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }

        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox2_TextChanged(object sender, EventArgs e) { }

        private void UserProfile_Load_1(object sender, EventArgs e)
        {

        }
    }
}