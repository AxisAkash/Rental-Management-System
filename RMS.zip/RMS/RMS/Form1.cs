﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMS
{
    public partial class Form1 : Form
    {
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // Create a gradient brush with multiple colors blended smoothly
            using (var brush = new System.Drawing.Drawing2D.LinearGradientBrush(
                this.ClientRectangle,
                Color.White,            
                Color.FromArgb(200, 220, 255), 
                System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                // Use a ColorBlend for smooth transition with 3 stops
                var blend = new System.Drawing.Drawing2D.ColorBlend();
                blend.Positions = new float[] { 0f, 0.5f, 1f };  // top, middle, bottom
                blend.Colors = new Color[]
                {
            Color.FromArgb(245, 248, 255), // very light sky blue at top
            Color.FromArgb(225, 236, 255), // soft mid blue
            Color.FromArgb(200, 220, 255)  // deeper blue at bottom
                };

                brush.InterpolationColors = blend;

                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        private bool _signupAsTenant = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Visible = false; // Login
            button2.Visible = false; // Sign Up
            pictureBox4.Visible = false; //login icon
            pictureBox5.Visible = false; //signup icon
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button1.Visible = true; // Login
            pictureBox4.Visible = true;
            pictureBox5.Visible = false;
            button2.Visible = false; // Sign Up
            _signupAsTenant = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Visible = true; // Login
            button2.Visible = true; // Sign Up
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            _signupAsTenant = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button1.Visible = true; // Login
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            button2.Visible = true; // Sign Up
            _signupAsTenant = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Open the Login form and hide the current Welcome form
            Login loginForm = new Login();
            loginForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignUp SignUpForm = new SignUp();
            SignUpForm.IsTenantSignup = _signupAsTenant;
            SignUpForm.Show();
            this.Hide();
        }
    }
    }

