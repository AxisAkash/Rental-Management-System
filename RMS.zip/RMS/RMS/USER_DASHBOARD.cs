﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Windows.Forms;
// DB: uncomment when you start wiring the database
// using System.Data.SqlClient;

namespace RMS
{
    public partial class USER_DASHBOARD : Form
    {


        string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(this.ClientRectangle,
                    Color.White, Color.FromArgb(220, 235, 255), // light blue
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }


        private DataTable _flats; 
        private DataTable _rooms; 

        public USER_DASHBOARD()
        {
            InitializeComponent();

            this.Load += USER_DASHBOARD_Load;


            button1.Click += BtnRooms_Click; // FLATS
            button2.Click += BtnFlats_Click; // ROOMS

            button3.Click += (s, e) => ApplySearch();            // SEARCH
            textBox1.TextChanged += (s, e) => ApplySearch();     // live search
            textBox1.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) ApplySearch(); };

            button5.Click += BtnSelect_Click; // SELECT
            button4.Click += BtnBook_Click;   // BOOK

            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.MultiSelect = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;

            dataGridView2.AutoGenerateColumns = true;
            dataGridView2.MultiSelect = false;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView2.ReadOnly = true;
        }

        private void USER_DASHBOARD_Load(object sender, EventArgs e)
        {
            button2.Visible = true;   // FLATS
            button1.Visible = true;   // ROOMS
            button7.Visible = true;   // BACK

            ShowSearchAndActions(false);
            dataGridView1.Visible = false;
            dataGridView2.Visible = false;

            
        }

        private void ShowSearchAndActions(bool visible)
        {
            button3.Visible = visible;  // Search button
            textBox1.Visible = visible; // Search box
            button5.Visible = visible;  // Select
            button4.Visible = visible;  // Book
        }

        // ---------- FLATS ----------
        private void BtnFlats_Click(object sender, EventArgs e)
        {
            if (_flats == null || _flats.Rows.Count == 0)
                _flats = LoadFlatsFromDb();

            dataGridView2.DataSource = _flats;
            dataGridView2.Visible = true;

            dataGridView1.Visible = false;
            ShowSearchAndActions(true);
            ApplySearch();
        }

        private void BtnRooms_Click(object sender, EventArgs e)
        {
            if (_rooms == null || _rooms.Rows.Count == 0)
                _rooms = LoadRoomsFromDb();

            dataGridView1.DataSource = _rooms;
            dataGridView1.Visible = true;

            dataGridView2.Visible = false;
            ShowSearchAndActions(true);
            ApplySearch();
        }

        // ---------- SEARCH on visible grid ----------
        private void ApplySearch()
        {
            DataGridView grid = null;
            if (dataGridView1.Visible) grid = dataGridView1;
            else if (dataGridView2.Visible) grid = dataGridView2;

            if (grid == null || grid.DataSource == null) return;

            string q = (textBox1.Text ?? string.Empty).Trim().Replace("'", "''");

            if (grid.DataSource is BindingSource)
            {
                BindingSource bs = (BindingSource)grid.DataSource;
                if (bs.DataSource is DataTable)
                {
                    DataTable dtB = (DataTable)bs.DataSource;
                    bs.Filter = q.Length == 0 ? null : BuildFilter(dtB, q);
                }
                return;
            }

            if (grid.DataSource is DataView)
            {
                DataView dv = (DataView)grid.DataSource;
                dv.RowFilter = q.Length == 0 ? string.Empty : BuildFilter(dv.Table, q);
                return;
            }

            if (grid.DataSource is DataTable)
            {
                DataTable dt = (DataTable)grid.DataSource;
                dt.DefaultView.RowFilter = q.Length == 0 ? string.Empty : BuildFilter(dt, q);
                grid.DataSource = dt.DefaultView;
            }
        }

        private string BuildFilter(DataTable table, string q)
        {
            IEnumerable<string> parts =
                table.Columns.Cast<DataColumn>()
                     .Select(c => $"CONVERT([{c.ColumnName}], 'System.String') LIKE '%{q}%'");
            return string.Join(" OR ", parts);
        }

        // ---------- SELECT ----------
        private void BtnSelect_Click(object sender, EventArgs e)
        {
            DataGridView grid = null;
            if (dataGridView1.Visible) grid = dataGridView1;
            else if (dataGridView2.Visible) grid = dataGridView2;

            if (grid == null || grid.CurrentRow == null)
            {
                MessageBox.Show("Please select a row first.");
                return;
            }

            if (grid.CurrentRow.DataBoundItem is DataRowView)
            {
                DataRowView drv = (DataRowView)grid.CurrentRow.DataBoundItem;
                DataRow row = drv.Row;
                IEnumerable<string> lines =
                    row.Table.Columns.Cast<DataColumn>()
                       .Select(c => $"{c.ColumnName}: {row[c]}");
                string details = string.Join(Environment.NewLine, lines);
                MessageBox.Show(details, "Selected");
            }
            else
            {
                IEnumerable<string> cells =
                    grid.CurrentRow.Cells.Cast<DataGridViewCell>()
                        .Select(c => $"{grid.Columns[c.ColumnIndex].HeaderText}: {c.Value}");
                MessageBox.Show(string.Join(Environment.NewLine, cells), "Selected");
            }
        }

        // ---------- BOOK ----------
        private void BtnBook_Click(object sender, EventArgs e)
        {
            DataGridView grid = null;
            if (dataGridView1.Visible) grid = dataGridView1;
            else if (dataGridView2.Visible) grid = dataGridView2;

            if (grid == null || grid.CurrentRow == null)
            {
                MessageBox.Show("Select a flat/room first.");
                return;
            }

            string itemType;
            object itemId;
            if (!TryGetSelectedId(grid, out itemType, out itemId))
            { 
            }

            // TODO(DB): insert booking into Bookings table
            // SaveBookingToDb(itemType, itemId);

            MessageBox.Show("Booking request submitted for " + itemType + " #" + itemId + "!");
        }
        private bool TryGetSelectedId(DataGridView grid, out string type, out object id)
        {
            type = (grid == dataGridView1) ? "Room"   // CHANGED: dataGridView1 is Rooms
                                           : "Flat";  // CHANGED: dataGridView2 is Flats
            id = null;

            if (grid.CurrentRow != null && grid.CurrentRow.DataBoundItem is DataRowView)
            {
                DataRowView drv = (DataRowView)grid.CurrentRow.DataBoundItem;
                DataRow row = drv.Row;

                string[] idNames = (type == "Flat")
                    ? new[] { "FlatId", "FlatID", "Id", "ID" }
                    : new[] { "RoomId", "RoomID", "Id", "ID" };

                foreach (string name in idNames)
                {
                    if (row.Table.Columns.Contains(name))
                    {
                        id = row[name];
                        return (id != DBNull.Value);
                    }
                }
            }
            return false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        // ====================== DB HOOKS: methods (stubs) ======================
        private DataTable LoadFlatsFromDb()
        {
        
            string query = "SELECT f.OwnerName,f.FlatID,f.Rent,f.Available FROM Flat f INNER JOIN owner s  ON f.OwnerName = s.name ORDER BY CASE WHEN s.premium = 'Yes' THEN 0 ELSE 1 END;"; // ✅ Only Rooms

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, con))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                adapter.Fill(dt);
            }
            return dt;
        }

        private DataTable LoadRoomsFromDb()
        {
            string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";
            string query = "SELECT f.OwnerName,f.FlatID,f.Rent,f.RoomNo, f.Available FROM Room f INNER JOIN owner s  ON f.OwnerName = s.name ORDER BY CASE WHEN s.premium = 'Yes' THEN 0 ELSE 1 END;"; // ✅ Only Rooms

            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, con))
            using (SqlDataAdapter adapter = new SqlDataAdapter(command))
            {
                adapter.Fill(dt);
            }
            return dt;
        }



        private void SaveBookingToDb(string itemType, object itemId)
        {
            // TODO(DB): insert booking row
            /*
            using (SqlConnection conn = new SqlConnection(_conn))
            using (SqlCommand cmd = new SqlCommand(
                @"INSERT INTO Bookings(ItemType, ItemId, UserId, CreatedAt)
                  VALUES (@type, @id, @user, SYSDATETIME())", conn))
            {
                cmd.Parameters.AddWithValue("@type", itemType);
                cmd.Parameters.AddWithValue("@id", itemId);
                cmd.Parameters.AddWithValue("@user", CurrentUserId);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            */
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserProfile userProfile = new UserProfile();
            userProfile.Show();
        }


        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void button4_Click(object sender, EventArgs e)
        {
            // Determine which grid is active
            DataGridView grid = null;
            if (dataGridView1.Visible) grid = dataGridView1; // Rooms
            else if (dataGridView2.Visible) grid = dataGridView2; // Flats

            if (grid == null || grid.CurrentRow == null)
            {
                MessageBox.Show("Please select a flat/room first.");
                return;
            }

            string tableName = (grid == dataGridView2) ? "Flat" : "Room";
            string idColumn = (tableName == "Flat") ? "FlatID" : "RoomNo";
            object idValue = grid.CurrentRow.Cells[idColumn].Value;
            object availableValue = grid.CurrentRow.Cells["Available"].Value;

            // Check if already booked
            if (availableValue != null && availableValue.ToString() == "0")
            {
                MessageBox.Show("This flat/room is already booked!");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = $"UPDATE {tableName} SET Available = 0 WHERE {idColumn} = @id AND Available = 1";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", idValue);
                    int affectedRows = cmd.ExecuteNonQuery();

                    if (affectedRows == 0)
                    {
                        MessageBox.Show("Booking failed. This flat/room may already be booked.");
                        return;
                    }
                }
            }

            // Reload only available items
            if (tableName == "Flat")
            {
                _flats = LoadFlatsFromDb();
                dataGridView2.DataSource = _flats;
            }
            else
            {
                _rooms = LoadRoomsFromDb();
                dataGridView1.DataSource = _rooms;
            }

            MessageBox.Show($"{tableName} booked successfully!");
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Home_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
    }

