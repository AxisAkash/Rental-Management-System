﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS
{
  
      // ★ ADDED: simple global holder instead of “Session”
        public static class AppState
        {
            public static int CurrentUserId { get; set; } = 0;
            public static string CurrentUserName { get; set; } = "";
            public static string CurrentUserRole { get; set; } = "";
        }


    }

