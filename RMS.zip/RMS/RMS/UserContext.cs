﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RMS
{
    internal class UserContext
    {

        public int UserId { get; set; }        // 0 if you don't have it yet
        public string UserName { get; set; }   // required
        public string Role { get; set; }       // optional ("Tenant", "Owner", etc.)
    }
}
