﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMS
{
    public partial class OWNERflats_RommsShow : Form
    {

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(this.ClientRectangle,
                    Color.White, Color.FromArgb(220, 235, 255), // light blue
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }
        
        public enum ViewToShow { Flats, Rooms }
        public ViewToShow DefaultView { get; set; } = ViewToShow.Flats;

       
       private DataTable _flats; 
       private DataTable _rooms; 



        private string FlatID;
       

        public OWNERflats_RommsShow(string FlatID)
        {
            InitializeComponent();
            this.FlatID = FlatID;
          
        }


        public OWNERflats_RommsShow()
        {
            InitializeComponent();
            this.Load += OWNERflats_RommsShow_Load;

        }

       
        private void OWNERflats_RommsShow_Load(object sender, EventArgs e)
        {
            PrepareGrid(dataGridView1); // Flats grid
            PrepareGrid(dataGridView2); // Rooms grid

            dataGridView1.Visible = false;
            dataGridView2.Visible = false;

            if (DefaultView == ViewToShow.Flats)
                ShowFlats();
            else
                ShowRooms();
        }

        private void PrepareGrid(DataGridView dgv)
        {
            dgv.AutoGenerateColumns = true;
            dgv.ReadOnly = true;
            dgv.MultiSelect = false;
            dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgv.RowHeadersVisible = false;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

      
        // ----- Show first grid (Flats) -----
        private void ShowFlats()
        {
            if (_flats == null)
                _flats = LoadFlatsFromDb(); // TODO(DB): SELECT * FROM Flats

            dataGridView1.DataSource = _flats;
            dataGridView1.Visible = true;
            dataGridView2.Visible = false;
        }

        // ----- Show second grid (Rooms) -----
        
        private void ShowRooms()
        {
            if (_rooms == null)
                _rooms = LoadRoomsFromDb(); // TODO(DB): SELECT * FROM Rooms

            dataGridView2.DataSource = _rooms;
            dataGridView2.Visible = true;
            dataGridView1.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e) // Back
        {
            OwnerDashboard ownerDashboard = new OwnerDashboard();
            this.Hide();
            ownerDashboard.Show();
        }

        // =================== DB HOOKS (stubs) ===================
        private DataTable LoadFlatsFromDb()
        {
            string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";

            // Get the current owner's name
            string ownerName = AppState.CurrentUserName; // Or get from your application state

            // Modified query to filter by specific owner
            string query = @"SELECT f.OwnerName, f.FlatID, f.Rent, f.Available 
                    FROM Flat f 
                    INNER JOIN owner s ON f.OwnerName = s.name 
                    WHERE f.OwnerName = @OwnerName
                    ORDER BY CASE WHEN s.premium = 'Yes' THEN 0 ELSE 1 END";

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.AddWithValue("@OwnerName", ownerName);
                con.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                return dataTable;
            }
        }


        private DataTable LoadRoomsFromDb()
        {
            string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";

            // Get the current owner's name (you might need to adjust this based on how you store owner info)
            string ownerName = AppState.CurrentUserName; // Or get from your application state

            // Modified query to filter by specific owner
            string query = @"SELECT f.OwnerName, f.FlatID, f.Rent, f.RoomNo, f.Available 
                    FROM Room f 
                    INNER JOIN owner s ON f.OwnerName = s.name 
                    WHERE f.OwnerName = @OwnerName
                    ORDER BY CASE WHEN s.premium = 'Yes' THEN 0 ELSE 1 END";

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, con))
            {
                command.Parameters.AddWithValue("@OwnerName", ownerName);
                con.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                return dataTable;
            }
        }

        private void OWNERflats_RommsShow_Load_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";

            string searchValue = textBox1.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchValue))
            {
                MessageBox.Show("Please enter a FlatID", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string searchQuery = @"
                            SELECT OwnerName, FlatID, Rent, Available
                            FROM Flat
                            WHERE OwnerName LIKE @searchTerm
                               OR FlatID LIKE @searchTerm
                               OR CAST(Rent AS NVARCHAR) LIKE @searchTerm
                               OR CAST(Available AS NVARCHAR) LIKE @searchTerm";


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(searchQuery, connection))
                {
                    command.Parameters.AddWithValue("@searchTerm", "%" + searchValue + "%");

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    dataGridView1.DataSource = dataTable;

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No matching rows found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";

            // Determine which grid is visible (flats or rooms)
            if (dataGridView1.Visible)
            {
                // Handle Flat deletion
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a flat to delete.", "Selection Required",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Get the FlatID from the selected row
                string flatIdToDelete = dataGridView1.SelectedRows[0].Cells["FlatID"].Value.ToString();

                // Confirm deletion
                DialogResult result = MessageBox.Show(
                    $"Are you sure you want to delete flat #{flatIdToDelete}?",
                    "Confirm Deletion",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (result == DialogResult.Yes)
                {
                    string query = "DELETE FROM Flat WHERE FlatID = @FlatID";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@FlatID", flatIdToDelete);

                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Flat deleted successfully!", "Success",
                                                MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Refresh the grid to show the updated data
                                _flats = LoadFlatsFromDb();
                                dataGridView1.DataSource = _flats;
                            }
                            else
                            {
                                MessageBox.Show("No flat was found to delete.", "Error",
                                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            else if (dataGridView2.Visible)
            {
                // Handle Room deletion
                if (dataGridView2.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a room to delete.", "Selection Required",
                                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string roomIdToDelete = dataGridView2.SelectedRows[0].Cells["FlatID"].Value.ToString();
                string flatIdForRoom = dataGridView2.SelectedRows[0].Cells["FlatID"].Value.ToString();

                // Confirm deletion
                DialogResult result = MessageBox.Show(
                    $"Are you sure you want to delete room #{roomIdToDelete} in flat #{flatIdForRoom}?",
                    "Confirm Deletion",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (result == DialogResult.Yes)
                {
                    string query = "DELETE FROM Room WHERE FlatID = @FlatID";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@FlatID", roomIdToDelete);
                            
                            connection.Open();
                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Room deleted successfully!", "Success",
                                                MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Refresh the grid to show the updated data
                                _rooms = LoadRoomsFromDb();
                                dataGridView2.DataSource = _rooms;
                            }
                            else
                            {
                                MessageBox.Show("No room was found to delete.", "Error",
                                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No data grid is currently visible.", "Information",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Home_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
    }

