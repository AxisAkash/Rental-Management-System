﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace RMS
{
    public partial class OwnerDashboard : Form
    {


        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(this.ClientRectangle,
                    Color.White, Color.FromArgb(220, 235, 255), // light blue
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }
        // Set from Login if needed (true → premium UI in profile)
        public bool IsPremiumOwner { get; set; } = false;

        // button2: Flats | button1: Rooms
        // button3: Total Flats | button4: Add Flats
        // button5: Total Rooms | button6: Add Rooms
        // button7: ADD (submit)

        public OwnerDashboard()
        {
            InitializeComponent();

            this.Load += OwnerDashboard_Load;

            button2.Click += btnFlats_Click;
            button1.Click += btnRooms_Click;
            button3.Click += btnTotalFlats_Click;
            button4.Click += btnAddFlats_Click;
            button5.Click += btnTotalRooms_Click;
            button6.Click += btnAddRooms_Click;
            button7.Click += btnAdd_Click;
        }

        private void OwnerDashboard_Load(object sender, EventArgs e)
        {
            if (string.Equals(AppState.CurrentUserRole, "Premium Owner", StringComparison.OrdinalIgnoreCase))
                IsPremiumOwner = true;
            ShowMainOnly();
        }

        // ---------- UI helpers ----------
        private void ShowMainOnly()
        {
            button2.Visible = true;   // Flats
            button1.Visible = true;   // Rooms

            button3.Visible = false;  // Total Flats
            button4.Visible = false;  // Add Flats
            button5.Visible = false;  // Total Rooms
            button6.Visible = false;  // Add Rooms

            ShowEntryForm(false, false);
        }

        private void ShowFlatsChoices()
        {
            button3.Visible = true;
            button4.Visible = true;

            button5.Visible = false;
            button6.Visible = false;

            ShowEntryForm(false, false);
        }

        private void ShowRoomsChoices()
        {
            button5.Visible = true;
            button6.Visible = true;

            button3.Visible = false;
            button4.Visible = false;

            ShowEntryForm(false, false);
        }

        /// <summary>Show/hide the entry section; Room No row optional for rooms.</summary>
        private void ShowEntryForm(bool visible, bool showRoomNo)
        {
            label1.Visible = visible;
            textBox1.Visible = visible;

            label2.Visible = visible;
            textBox2.Visible = visible;

            label4.Visible = visible;
            textBox4.Visible = visible;

            button7.Visible = visible; // ADD

            label3.Visible = visible && showRoomNo;
            textBox3.Visible = visible && showRoomNo;

            if (visible)
            {
                textBox1.Text = string.Empty;
                textBox2.Text = string.Empty;
                textBox3.Text = string.Empty;
                textBox4.Text = string.Empty;
            }
        }

        // ---------- Button handlers ----------
        private void btnFlats_Click(object sender, EventArgs e) { ShowFlatsChoices(); }
        private void btnRooms_Click(object sender, EventArgs e) { ShowRoomsChoices(); }

        private void btnTotalFlats_Click(object sender, EventArgs e) { ShowEntryForm(false, false); }
        private void btnAddFlats_Click(object sender, EventArgs e) { ShowEntryForm(true, false); }

        private void btnTotalRooms_Click(object sender, EventArgs e) { ShowEntryForm(false, false); }
        private void btnAddRooms_Click(object sender, EventArgs e) { ShowEntryForm(true, true); }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            bool addingRoom = textBox3.Visible; // true → adding room, false → adding flat

            // Get input values
            string OwnerName = textBox1.Text.Trim();
            string FlatID = textBox2.Text.Trim();
            string RoomNo = textBox3.Text.Trim();
            string Rent = textBox4.Text.Trim();

            // Validate required fields
            if (string.IsNullOrWhiteSpace(OwnerName) ||
                string.IsNullOrWhiteSpace(FlatID) ||
                string.IsNullOrWhiteSpace(Rent) ||
                (addingRoom && string.IsNullOrWhiteSpace(RoomNo)))
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";

            if (addingRoom) // ADD ROOM
            {
                string queryRoom = "INSERT INTO Room(OwnerName, FlatID, RoomNo, Rent, Available) VALUES(@OwnerName, @FlatID, @RoomNo, @Rent, 1)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(queryRoom, connection))
                    {
                        command.Parameters.AddWithValue("@OwnerName", OwnerName);
                        command.Parameters.AddWithValue("@FlatID", FlatID);
                        command.Parameters.AddWithValue("@RoomNo", int.Parse(RoomNo));
                        command.Parameters.AddWithValue("@Rent", float.Parse(Rent));

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Room added successfully and set as Available!");
                            ShowMainOnly();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add room. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else // ADD FLAT
            {
                string queryFlat = "INSERT INTO Flat(OwnerName, FlatID, Rent, Available) VALUES(@OwnerName, @FlatID, @Rent, 1)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(queryFlat, connection))
                    {
                        command.Parameters.AddWithValue("@OwnerName", OwnerName);
                        command.Parameters.AddWithValue("@FlatID", FlatID);
                        command.Parameters.AddWithValue("@Rent", float.Parse(Rent));

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Flat added successfully and set as Available!");
                            ShowMainOnly();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add flat. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {

            OWNER_PROFILE op = new OWNER_PROFILE();
            op.IsPremiumOwner = this.IsPremiumOwner;

            // ✅ ADDED: when profile closes, show the SAME dashboard again
            op.FormClosed += (s, args) => this.Show();

            this.Hide();   // keep hiding the dashboard
            op.Show();     // (or op.ShowDialog(this); if you prefer modal)
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OWNERflats_RommsShow list = new OWNERflats_RommsShow();
            list.DefaultView = OWNERflats_RommsShow.ViewToShow.Flats;
            this.Hide();
            list.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OWNERflats_RommsShow list = new OWNERflats_RommsShow();
            list.DefaultView = OWNERflats_RommsShow.ViewToShow.Rooms;
            this.Hide();
            list.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Home_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}