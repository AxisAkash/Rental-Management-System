﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMS
{
    public partial class OWNER_PROFILE : Form
    {
        // Keep your smooth gradient background


        private readonly string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";
        private int _userId = 0;


        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(
                    this.ClientRectangle,
                    Color.White,
                    Color.FromArgb(220, 235, 255),
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {

                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        // Pass from OwnerDashboard (e.g., after login)
        public bool IsPremiumOwner { get; set; } = false;

        // Optional: current owner id (set from your login/session)
        public int? CurrentOwnerId { get; set; } = null;

        public OWNER_PROFILE()
        {
            InitializeComponent();

            // Wire if not wired in Designer
            this.Load += OWNER_PROFILE_Load;
            // button1 = Edit, button2 = Update, button7 = Back
            button1.Click += button1_Click;
            button2.Click += button2_Click;
            button7.Click += button7_Click;
        }

        private void OWNER_PROFILE_Load(object sender, EventArgs e)
        {
            // Show Premium row only for Premium Owner
            label3.Visible = IsPremiumOwner;
            textBox3.Visible = IsPremiumOwner;

            if (AppState.CurrentUserId <= 0)
            {
                MessageBox.Show("No logged-in user found.");
                Close();
                return;
            }
            _userId = AppState.CurrentUserId;


            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

        }

        // ---------------- Navigation ----------------
        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ---------------- Edit ----------------
        private void button1_Click(object sender, EventArgs e)
        {
            SetEditMode(true);

            LoadOwnerProfile();
            SetEditMode(true);
            textBox2.UseSystemPasswordChar = false;
            textBox1.Focus();
            textBox1.SelectAll();

        }
        private void LoadOwnerProfile()
        {
            string query = "SELECT Id, name, password, premiumPass FROM owner WHERE Id = @Id";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", _userId);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            textBox1.Text = reader["name"].ToString();
                            textBox2.Text = reader["password"].ToString();
                            textBox3.Text = reader["premiumPass"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("Owner not found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading profile: " + ex.Message);
            }
        }
        // =======================================================


        // ---------------- Update (Save) ----------------
        private void button2_Click(object sender, EventArgs e)
        {


            string newName = textBox1.Text.Trim();
            string newPassword = textBox2.Text.Trim();
            string newPremiumPass = textBox3.Text.Trim();

            if (_userId <= 0)
            {
                MessageBox.Show("Cannot update: user id missing.");
                return;
            }

            try
            {
                string query = "UPDATE owner SET name = @name, password=@password, premiumPass=@premiumPass WHERE Id = @Id";
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@name", newName);
                    cmd.Parameters.AddWithValue("@password", newPassword);
                    cmd.Parameters.AddWithValue("@premiumPass", newPremiumPass);
                    cmd.Parameters.AddWithValue("@Id", _userId);

                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Profile updated successfully.");
                        AppState.CurrentUserName = newName;
                        SetEditMode(false);
                        textBox2.UseSystemPasswordChar = true;
                    }
                    else
                    {
                        MessageBox.Show("Update failed. Please try again.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating profile: " + ex.Message);
            }
        }

        // ========================================================

        // ---------------- Helpers ----------------
        private void SetEditMode(bool enabled)
        {
            textBox1.ReadOnly = !enabled; // Name
            textBox2.ReadOnly = !enabled; // Password
            if (IsPremiumOwner) textBox3.ReadOnly = !enabled; // Premium Password

            textBox1.BackColor = enabled ? Color.White : SystemColors.ControlLightLight;
            textBox2.BackColor = enabled ? Color.White : SystemColors.ControlLightLight;
            if (IsPremiumOwner) textBox3.BackColor = enabled ? Color.White : SystemColors.ControlLightLight;

            button1.Enabled = !enabled; // Edit
            button2.Enabled = enabled;  // Update
        }

        private bool ValidateInputs()
        {
            string name = (textBox1.Text ?? string.Empty).Trim();
            string pwd = textBox2.Text ?? string.Empty;
            string ppwd = IsPremiumOwner ? (textBox3.Text ?? string.Empty) : string.Empty;

            if (name.Length == 0)
            {
                MessageBox.Show("Please enter your name.");
                textBox1.Focus();
                return false;
            }

            // Passwords are optional to change; enforce minimum only if user typed them
            if (pwd.Length > 0 && pwd.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters.");
                textBox2.Focus();
                return false;
            }

            if (IsPremiumOwner && ppwd.Length > 0 && ppwd.Length < 6)
            {
                MessageBox.Show("Premium password must be at least 6 characters.");
                textBox3.Focus();
                return false;
            }

            return true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            button1_Click(sender, e);   // forward to your real Edit handler
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            button2_Click(sender, e);   // forward to your real Update handler
        }
    }
}
