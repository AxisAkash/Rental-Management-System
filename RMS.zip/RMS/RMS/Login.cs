﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace RMS
{
    public partial class Login : Form
    {
        string connectionString = "data source=DESKTOP-RCGMV5F\\SQLEXPRESS; database=C# Final; integrated security=SSPI";
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (System.Drawing.Drawing2D.LinearGradientBrush brush =
                new System.Drawing.Drawing2D.LinearGradientBrush(this.ClientRectangle,
                    Color.White, Color.FromArgb(220, 235, 255), // light blue
                    System.Drawing.Drawing2D.LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, this.ClientRectangle);
            }
        }

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                string selectedRole = comboBox1.SelectedItem.ToString();

                if (selectedRole == "Premium Owner")
                {
                    label4.Visible = true;
                    textBox3.Visible = true;   // Premium password input
                }
                else
                {
                    label4.Visible = false;
                    textBox3.Visible = false;
                }
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            // Hide Premium Password UI at startup
            label4.Visible = false;
            textBox3.Visible = false;

            // Populate roles (keep if not done in Designer)
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Admin");
            comboBox1.Items.Add("Owner");
            comboBox1.Items.Add("Tenant");
            comboBox1.Items.Add("Premium Owner");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int GetIntSafe(SqlDataReader r, string columnName)
            {
                int ordinal;
                try { ordinal = r.GetOrdinal(columnName); }
                catch { return 0; }
                if (r.IsDBNull(ordinal)) return 0;
                return Convert.ToInt32(r.GetValue(ordinal));
            }

            string name = textBox1.Text;
            string password = textBox2.Text;
            string role = comboBox1.SelectedItem?.ToString();
            string premiumPass = textBox3.Text;

            // ✅ Basic validation
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(password) || role == null)
            {
                MessageBox.Show("Please fill all required fields.");
                return;
            }

            // ✅ Admin login (hardcoded)
            if (role == "Admin")
            {
                string defaultAdminName = "admin";
                string defaultAdminPassword = "Admin123";

                if (name.Equals(defaultAdminName, StringComparison.OrdinalIgnoreCase)
                    && password == defaultAdminPassword)
                {
                    MessageBox.Show("Admin login successful!");
                    ADMIN_DASHBOARD form = new ADMIN_DASHBOARD();
                    form.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid admin credentials.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                return;
            }

            // ✅ Database connection
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "";

                if (role == "Owner")
                {
                    // Normal Owner: must not be premium
                    query = "SELECT * FROM [owner] WHERE name=@name AND password=@password AND premium='No'";
                }
                else if (role == "Premium Owner")
                {
                    // Premium Owner: must have premium=Yes and correct premiumPass
                    query = "SELECT * FROM [owner] WHERE name=@name AND password=@password AND premium='Yes' AND premiumPass=@premiumPass";
                }
                else if (role == "Tenant")
                {
                    query = "SELECT * FROM [user] WHERE name=@name AND password=@password";
                }

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@name", name);
                    command.Parameters.AddWithValue("@password", password);

                    if (role == "Premium Owner")
                    {
                        if (string.IsNullOrWhiteSpace(premiumPass))
                        {
                            MessageBox.Show("Please enter your Premium Password.");
                            return;
                        }
                        command.Parameters.AddWithValue("@premiumPass", premiumPass);
                    }

                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // ✅ Role-specific dashboards
                        if (role == "Owner")
                        {
                            MessageBox.Show("Owner login successful!");
                            AppState.CurrentUserId = GetIntSafe(reader, "Id");
                            AppState.CurrentUserName = name;
                            AppState.CurrentUserRole = "Owner";

                            OwnerDashboard form = new OwnerDashboard();
                            form.Show();
                            this.Hide();
                        }
                        else if (role == "Tenant")
                        {
                            MessageBox.Show("Tenant login successful!");
                            AppState.CurrentUserId = GetIntSafe(reader, "Id");
                            AppState.CurrentUserName = name;
                            AppState.CurrentUserRole = "Tenant";

                            USER_DASHBOARD form = new USER_DASHBOARD();
                            form.Show();
                            this.Hide();
                        }
                        else if (role == "Premium Owner")
                        {
                            MessageBox.Show("Premium Owner login successful!");
                            AppState.CurrentUserId = GetIntSafe(reader, "Id");
                            AppState.CurrentUserName = name;
                            AppState.CurrentUserRole = "Premium Owner";

                            OwnerDashboard form = new OwnerDashboard();
                            form.Show();
                            this.Hide();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid credentials or role mismatch.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

    }
}